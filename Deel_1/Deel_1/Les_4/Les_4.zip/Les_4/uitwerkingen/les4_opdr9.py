print( round (431 / 100 *100) )
# een deeling waarbij een breuk onstaat is niet precies het getal dat je ziet