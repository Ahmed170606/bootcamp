naam = 'ahmed'
greetings = 'hello'


print(naam + " " +greetings+ " " + 'ik leer nu programmeren' )