print( (24*60) *60 )
# 86400 secondes in 1 dag
print (" ")

print((24*7*60) *60 )
# 604800 secondes in 1 week

print (" ")

print( (24*365*60) *60)
# 31 556 926

#Schrijf een programma wat uitrekent hoeveel seconden er in een dag zitten. 
# (en in een week) (en in een jaar)