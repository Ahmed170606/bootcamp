
naam =int (252)
greeting = 'hello'

print(int + naam + greeting+'ik leer nu programmeren' )