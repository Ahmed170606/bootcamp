print( int (625/13)   )




#(hint: gebruik de modulo en integer deling (of floor division))