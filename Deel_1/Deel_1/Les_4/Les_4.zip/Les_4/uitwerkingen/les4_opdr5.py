x = (25)
a = (0)
print(x/a)
# divison by zero, der wordt met niks gedeeld '0'