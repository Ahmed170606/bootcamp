# print( ((2*3 /4 + (5 -6/7) *8 )
# verbeterd versie:
print( (2*3 /4) + (5 -6/7) *8 )
# We verwachten: 34.642857142857146
print( ((12*13 /14) + (15 -16) /17) *18 )
# We verwachten: 199.5126050420168