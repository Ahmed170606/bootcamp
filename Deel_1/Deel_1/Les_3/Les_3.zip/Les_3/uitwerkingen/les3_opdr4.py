# opdr 4
woord_1 = input ("Wat voor soort dag moet het zijn?")
stad_1 = input ("welke stad meot het zijn?")
naam_1 = input ("hoe heet het persoon?")
woord_3 = input ("op wat is hij/zij op zoek?")
woord_4 = input ("welke bijvoegelijk naamwoord wil je zetten?")
woord_5 = input ("wat verkocht de man/vrouw?")
woord_zin_7 =input  ('waar kwam de persoon aan?')
woord_6 = input ("wat zijn die groep mensen aan het doen?")


print(' ')
print(' ')

print('Het was een ' +woord_1+ ' dag in ' +stad_1+ '.') 
print(''+naam_1+ ' liep door de straten, op zoek naar een ' +woord_3+ '.')
print(' Plotseling ' +naam_1+ 'je een' +woord_4+ ' man/vrouw die een ' +woord_5+ 'verkocht' )
print('' +naam_1+ 'besloot om het te kopen en liep verder.')
print('Toen ' +naam_1+ 'bij een ' +woord_6+ 'kwam, zag hij/zij een groep mensen die' +woord_zin_7+ '.')
print('' +naam_1+ 'besloot om mee te doen en had de tijd van zijn/haar leven.')