# a
print(23*1115)
# b
print(3.40 / 100 * 9)
print(2.45 / 100 * 9)
print(1.95 / 100 * 9)

